import numpy as np

arr = np.array(range(1,10),int)
print("Output:",*arr)
