import sys

string = sys.argv
print(*string[1:])
