string = input("Enter string:")
sub = input("Enter substring to remove:")
string =  string.replace(sub, "")

print("String after removal:",string)
