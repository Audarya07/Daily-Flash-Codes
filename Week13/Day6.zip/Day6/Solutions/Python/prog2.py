string = input("Enter string:")

cnt = 0

print("No. of words:",string.count(" ")+1)
