s1 = input("Enter string 1:")
s2 = input("Enter string 2:")

print("String after concatenation:",s1+s2)
