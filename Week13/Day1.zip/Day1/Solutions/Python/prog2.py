string = input("Enter string:")

rev = string[::-1]
print("Reversed string:",rev)
