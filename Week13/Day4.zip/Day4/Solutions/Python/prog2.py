string = input("Enter string:")

print("String after replace:",string.swapcase())
