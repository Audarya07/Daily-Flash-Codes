string = input("Enter string:")
index = int(input("Enter index to remove:"))
string =  string.replace(string[index],"")

print("String after removal:",string)
