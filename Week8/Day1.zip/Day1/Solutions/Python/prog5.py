num = 1

while num % 7 != 0:
    num = int(input())
else:
    print("Exiting code",num,"is divisible by 7")
