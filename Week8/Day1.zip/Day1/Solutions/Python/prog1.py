num = input()

if '0' in num and num[0] != '0':
    print(num,"is a Duck number!!")
else:
    print(num,"is not Duck number")


