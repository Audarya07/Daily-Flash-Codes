num = 1

while num != 0:
    num = int(input())
else:
    print("Exiting Code,You entered Zero")

