num = 0
while num >= 0:
    num = int(input())
    if num < 0:
        print("Entered negative number!!")
    else:
        print("Cube = ",num**3)
