num = input()

if (int(num)**2) % 10 == int(num):
    print(num,"is Automorphic number")
else:
    print(num,"is not Automorphic")
