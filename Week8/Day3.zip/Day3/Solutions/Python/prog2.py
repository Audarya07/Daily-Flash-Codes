for num in range(1,500):
    if '0' in str(num) and str(num)[0] != '0':
        print(num)

