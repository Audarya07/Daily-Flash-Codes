num = input()

num = num[-1]+num[1:-1]+num[0]
print("Swap = ",num)
