num = int(input())

print("Cube root =",num**(1/3))
