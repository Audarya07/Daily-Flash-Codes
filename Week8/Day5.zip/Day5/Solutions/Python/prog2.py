num = input()

for i in num:
    if i == "1":
        num = num.replace(i,"2")
print("Output:",num)
