int printf(const char*,...);
int scanf(const char*,...);

void main(){
	char x;
	printf("\nEntr character = ");
	scanf("%c",&x);
	printf("ASCII value is = %d\n",x);
}
