x = input("Enter character = ")

print("ASCII value of",x,"is",ord(x))
