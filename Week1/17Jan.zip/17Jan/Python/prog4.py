for i in range(4):
    x = 2
    for i in range(4):
        print(x,end=" ")
        x += 2
    print()
