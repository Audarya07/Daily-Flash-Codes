import math
r = float(input("Enter radius of circle = "))

area = math.pi * r * r

print("Area of circle = ",area)
