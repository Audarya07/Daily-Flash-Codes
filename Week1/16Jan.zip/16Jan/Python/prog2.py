
p = int(input("Enter principal amount = "))
r = int(input("Enter rate of interest = "))
t = int(input("Enter term of deposit(in yrs) = "))

si = p*r*t/100
print("Simple Interest =",si)
