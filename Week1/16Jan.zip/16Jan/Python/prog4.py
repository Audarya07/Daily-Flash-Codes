k=1
for i in range(4):
    for j in range(4):
        print(k,end="  ")
        k+=1
    print(" ")
