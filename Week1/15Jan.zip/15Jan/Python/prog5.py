x = [int(x) for x in input().split()]

if sum(x) != 180:
    print("The traingle is invalid one")
else:
    print("The traingle is valid one")

