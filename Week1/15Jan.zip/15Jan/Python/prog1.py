x = input()

if x.islower():
    print("letter",x,"is lowercase")
else:
    print("letter",x,"is uppercase")
