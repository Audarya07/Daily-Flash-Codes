x = int(input())

if x % 5 == 0 and x % 11 == 0:
    print(str(x) + " is divisible by 5 & 11")
else:
    print(str(x) + " is not divisible by 5 & 11")
