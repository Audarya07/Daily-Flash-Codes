x = int(input())

if x % 2 == 0:
    print(str(x) + " is Even Number!")
else:
    print(str(x) + " is Odd Number!")
