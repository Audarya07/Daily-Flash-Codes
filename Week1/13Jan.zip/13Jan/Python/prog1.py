x = int(input())
y = int(input())
if x > y:
    print(str(x) + " is Max number among " + str(x) + " & " + str(y))
else:    
    print(str(y) + " is Max number among " + str(x) + " & " + str(y))
