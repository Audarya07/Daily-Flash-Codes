x = int(input())

if x == 0:
    print(str(x) + " is zero")
elif x < 0: 
    print(str(x) + " is the negative number")
else:
    print(str(x) + " is the positive number")
