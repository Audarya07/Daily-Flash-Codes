for i in range(4):
    for i in range(4):
        print("1",end=" ")
    print()
