x = [int(x) for x in input().split()]

print(max(x),"is Max")
