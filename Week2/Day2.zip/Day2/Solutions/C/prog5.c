int printf(const char*,...);
int scanf(const char*,...);

void main(){
	for(int i=0;i<4;i++){
		for(int j=0;j<=i;j++){
			printf("0 ");
		}
	printf("\n");
	}
}
