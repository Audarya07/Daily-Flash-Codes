int printf(const char*,...);
int scanf(const char*,...);

void main(){
	int i;
	for(i=1;i<=10;i++)
		printf("Square of %d:%d\n",i,i*i);
}
