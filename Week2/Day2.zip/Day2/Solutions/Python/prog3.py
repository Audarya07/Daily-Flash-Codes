x = 2
for i in range(1,11):
    print(x*i,end=" ")
print()
