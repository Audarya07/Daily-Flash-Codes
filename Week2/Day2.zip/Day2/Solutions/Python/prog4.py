x = int(input())
for i in range(1,11):
    print(x*i,end=" ")
print()
