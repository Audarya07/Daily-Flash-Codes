for i in range(1,21):
    print("Cube of",i,":",i**3)
