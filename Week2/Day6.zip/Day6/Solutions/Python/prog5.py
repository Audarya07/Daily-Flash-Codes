var_list = [int(num) for num in input().split()][:2]

print("The Maximum number amongst",*var_list,"is",max(var_list))


