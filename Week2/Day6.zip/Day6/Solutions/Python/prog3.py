num = int(input())

for i in range(2,num+1,2):
    print("Cube of",i,":",i**3,"and Square of",i,":",i**2)

