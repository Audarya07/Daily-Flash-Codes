num1,num2 = [int(x) for x in input().split()]

print("Addition is",num1+num2)

if num1>num2:
    print("Subtraction is",num1-num2)
else:
    print("Subtraction is",num2-num1)
