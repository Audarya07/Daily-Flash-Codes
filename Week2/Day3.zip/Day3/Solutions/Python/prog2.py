num1,num2 = [int(x) for x in input().split()]

print("Multiplication is",num1*num2)

if num1>num2:
    print("Division is",num1/num2)
else:
    print("Division is",num2/num1)
