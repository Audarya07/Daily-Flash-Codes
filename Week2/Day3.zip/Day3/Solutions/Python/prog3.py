num1,num2 = [int(x) for x in input().split()]

print("Addition of",num1**3,"&",num2**3,"is",num1**3+num2**3)
print("Subtraction of",num1**2,"&",num2**2,"is",num1**2-num2**2)
