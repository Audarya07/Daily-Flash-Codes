x = list(int(x) for x in input().split())[:10]

print("Sum = ",sum(x))
print("Average = ",sum(x)/len(x))

