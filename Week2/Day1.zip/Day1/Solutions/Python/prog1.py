x = int(input())
print("Output =",x)
