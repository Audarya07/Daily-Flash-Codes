x = int(input())
ans=0
for i in range(x+1):
    ans+=i
print("The sum upto",x,"is",ans)
