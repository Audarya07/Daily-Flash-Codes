x = int(input())
if x%2==0:
    print(x,"is Even Number")
else:
    print(x,"is Odd Number")
