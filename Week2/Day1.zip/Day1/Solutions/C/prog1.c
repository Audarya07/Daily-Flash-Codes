int printf(const char*,...);
int scanf(const char*,...);

void main(){
	 int x;
	 scanf("%d",&x);
	 printf("Output = %d\n",x);
}
