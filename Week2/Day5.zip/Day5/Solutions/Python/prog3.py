var = int(input())
for i in range(1,var):
    print("Cube of",i,":",i**3,"and Square of",i,":",i**2)
print()
