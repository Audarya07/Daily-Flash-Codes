for i in range(5):
    for j in range(i+1):
        if i%2==0:
            print("0",end=" ")
        else:
            print("1",end=" ")
    print()
