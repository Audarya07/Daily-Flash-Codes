int printf(const char*,...);
int scanf(const char *,...);

void main() {
	int i;
	for(i=1;i<=100;i++){
		if(i%3==0 || i%5==0)
			printf("%d ",i);
	}
	printf("\n");	
}
