x = int(input("Enter number:"))
fact = 1
for i in range(1,x+1):
    fact *= i
print("Factorial is:",fact)
