length = float(input("Length of pendulum:"))

time = 2*(3.142)*(length/9.81)**0.5

print("Period of pendulum:",round(time,2),"seconds")
