string = input("Enter sentence:")
cnt = string.count(" ")

print("String contains",cnt+1,"words")
