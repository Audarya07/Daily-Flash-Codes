freq = float(input("Frequency of pendulum:"))

time = 1/freq

print("Length of pendulum:",round(time,4),"meters")


