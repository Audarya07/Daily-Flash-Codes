freq = float(input("Frequency of pendulum:"))

length =9.18 / (4*(3.142**2)*(freq**2))

print("Length of pendulum:",round(length,4),"meters")


