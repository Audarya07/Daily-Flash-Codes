time = float(input("Period of pendulum:"))

length = (9.18*(time**2))/(4*(3.142**2))

print("Length of pendulum:",round(length,2),"meters")


