string = input("Enter string:")

print("Length of string:",len(string))
