list1 = [int(var) for var in input().split()][:3]

print("Maximum is:",max(list1))
