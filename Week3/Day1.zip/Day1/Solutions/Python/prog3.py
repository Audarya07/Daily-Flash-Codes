dist = int(input("Distance(in m):"))
time = int(input("Time(in sec):"))

print("The velocity of particle is : ",dist/time,"m/s")
