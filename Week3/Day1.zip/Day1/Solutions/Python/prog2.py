nums = [int(var) for var in input().split()][:2]

print("The minimum number amongst",*nums,"is",min(nums))
