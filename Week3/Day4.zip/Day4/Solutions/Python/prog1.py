x = int(input())
y = int(input())
print("Before swap:",x,y)
x,y = y,x
print("After swap:",x,y)
