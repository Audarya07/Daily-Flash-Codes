num1 = int(input())
num2 = int(input())

print("Quotient:",num1//num2)
print("Remainder:",num1%num2)
