mass = int(input("Mass(in kg):"))
vel = int(input("Velocity(in m/s):"))
print("Kinetic energy of the object is:",0.5*mass*(vel**2))
