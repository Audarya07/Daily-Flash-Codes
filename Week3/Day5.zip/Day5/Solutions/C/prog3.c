int printf(const char*,...);
int scanf(const char*,...);

void main() {
	int i,j;
	for(i=0;i<5;i++){
		for(j=5;j>i;j--){
			printf("%c ",i+65);
		}
	printf("\n");
	}
}
