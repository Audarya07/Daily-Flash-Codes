rup = float(input("Enter amount in rupees:"))
print("Amount in dollar:",round(rup/71.6,4))
