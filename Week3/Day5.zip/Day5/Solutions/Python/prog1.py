num = int(input())
j = 1
for i in range(10):
    print(j,end=" ")
    j+=num
print()
