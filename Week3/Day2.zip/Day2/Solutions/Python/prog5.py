list1 = [int(var) for var in input().split()][:3]

print("Minimum is:",min(list1))
