cur = int(input("I = "))
res = int(input("R = "))

print("Voltage V = ",cur*res)
