hr = float(input("Hrs = "))
print(int(hr*60*60),"seconds")
