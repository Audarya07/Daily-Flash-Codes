l = int(input("Enter length:"))
b = int(input("Enter breadth:"))
print("Area of rectangle:",l*b)
