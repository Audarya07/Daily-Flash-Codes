num = int(input())

print("Second Predecessor:",num-2)
print("Second Successor:",num+2)
