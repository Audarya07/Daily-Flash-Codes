num = int(input())

for i in range(10,0,-1):
    print(num,"x",i,"=",num*i)

