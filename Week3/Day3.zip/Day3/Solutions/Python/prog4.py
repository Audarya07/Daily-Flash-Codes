for i in range(4,0,-1):
    for j in range(5-i):
        print(i-1,end=" ")
        i+=1
    print()
