num = input("Enter hexadecimal number:")
res = int(num,16)
print("Decimal number:",res)

