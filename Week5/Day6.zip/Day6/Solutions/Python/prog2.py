num = input("Enter hexadecimal number:")
dec = int(num,16)
print("Octal number:",str(oct(dec)).strip("0o"))
