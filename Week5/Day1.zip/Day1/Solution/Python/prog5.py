num = int(input("Enter number:"))
print("The number",str(num),"has",len(str(num)),"digits")
