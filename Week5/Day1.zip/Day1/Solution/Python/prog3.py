while(1):
    i = int(input())
    if i<0:
        break
    else:
        print("->",i)

