num = int(input())

while(num>=0):
    if num%2==0:
        print(num,end=" ")
    num-=1
print()
