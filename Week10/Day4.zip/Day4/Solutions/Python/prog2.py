string = input("Entered string:")

print("Reversed string:",string[::-1])
