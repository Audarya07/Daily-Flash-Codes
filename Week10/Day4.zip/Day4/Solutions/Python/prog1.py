deg = int(input("Enter in degree:"))

rad = (deg*3.14)/180

print("In radians:",rad)
