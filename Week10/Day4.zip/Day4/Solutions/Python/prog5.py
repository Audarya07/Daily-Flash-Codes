area = int(input("Enter area:"))
ht = int(input("Enter height:"))

base = (2 * area) / ht

print("Base of triangle:",round(base,2))
