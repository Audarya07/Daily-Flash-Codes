ht = int(input("Enter height:"))
base = int(input("Enter base:"))
area = ht * base * 0.5

print("Area of triangle:",round(area,2))
