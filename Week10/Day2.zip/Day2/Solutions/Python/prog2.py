string = input("Input(in upper case):")

print("Output:",string.lower())
