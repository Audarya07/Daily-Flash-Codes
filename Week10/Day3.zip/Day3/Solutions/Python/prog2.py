string = input("Enter string:")

print("length:",len(string))
