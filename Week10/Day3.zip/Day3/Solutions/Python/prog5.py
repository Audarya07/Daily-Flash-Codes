area = int(input("Enter area:"))
base = int(input("Enter base:"))
ht = (2 * area) / base

print("Height of triangle:",round(ht,2))
