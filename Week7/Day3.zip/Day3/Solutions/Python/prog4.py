for i in range(4):
    for j in range(4,i,-1):
        print("*",end=" ")
    print()

