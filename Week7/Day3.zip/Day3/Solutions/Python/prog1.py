for val in range(300,601):
    if str(val) == str(val)[::-1]:
        print(val,end=" ")
print()
