num = int(input())
print("Square root of",num,"is",int(num**0.5))
