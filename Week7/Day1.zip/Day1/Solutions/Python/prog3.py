l = ['white-black','black-white','white-black','black-white']
num = int(input("Number of rows: "))

for i in range(num):
    print(*l)
