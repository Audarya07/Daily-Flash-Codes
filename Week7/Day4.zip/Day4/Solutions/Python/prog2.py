area = float(input("Enter area of circle = "))

print("Radius of the circle = ",round((area/3.142)**0.5,2))

