def midpoint(a,b):
    x = (a[0]+b[0])/2
    y = (a[1]+b[1])/2
    return (x,y)

print("Mid-point of line AB:",midpoint((4,5),(2,4)))
