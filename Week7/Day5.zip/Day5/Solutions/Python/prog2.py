circum = float(input("Enter circumference of circle: "))

print("Diameter of circle is = ",round(circum/3.142,2))

