l = int(input("Last element in AP = "))
d = int(input("Common difference = "))

while l:
    print(l,end=" ")
    l-=d
print()
