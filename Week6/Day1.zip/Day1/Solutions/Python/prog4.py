for i in range(5):
    num = 5
    for j in range(5):
        if i>j:
            print(" ",end=" ")
        else:
            print(num,end=" ")
        num-=1
    print()


