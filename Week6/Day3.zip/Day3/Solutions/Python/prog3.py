circum = float(input("Circumference of circle:"))
print("Radius of circle is:",circum/(2*3.142))
