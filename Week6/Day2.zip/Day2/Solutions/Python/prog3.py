rad = int(input("Radius = "))

print("Circumference of circle with radius",rad,"is",round(2*3.142*rad,3))
