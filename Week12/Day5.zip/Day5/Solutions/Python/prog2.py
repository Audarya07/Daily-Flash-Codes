string = input("Enter string:")

string1 = string[:]
print("Output string 2:",string1)
