string = input("Enter string:")
char = input("Enter character to find occurence of:")

print("The occurence of",char,"in the entered string:",string.count(char))
