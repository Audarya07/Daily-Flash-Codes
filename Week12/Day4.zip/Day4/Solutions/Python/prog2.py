string = input("Enter string:")

if string == string[::-1]:
    print("Entered string is palindrome")
else:
    print("entered string not palindrome")
