string = input("Entere string:")
s = int(input("Enter start index:"))
e = int(input("Enter end index:"))

new = string[s:e+1]

print("Output string aftere copying:",new)
