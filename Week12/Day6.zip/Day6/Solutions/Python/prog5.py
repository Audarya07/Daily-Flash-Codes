a = int(input("Enter value of a:"))
b = int(input("Enter value of b:"))
c = int(input("Enter value of c:"))

x1 = ((-b) + ((b*b) - (4*a*c))**0.5) /(2*a)
x2 = ((-b) - ((b*b) - (4*a*c))**0.5) /(2*a)

print("Value of x1:",x1)
print("Value of x2:",x2)
