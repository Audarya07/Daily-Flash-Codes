km = float(input("Enter distance in kilometer:"))
print(km,"km is equal to",int(1000*km),"m")

