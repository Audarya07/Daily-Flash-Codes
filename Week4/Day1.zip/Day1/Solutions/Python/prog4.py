for i in range(5):
    for j in range(4,i,-1):
        print(chr(i+65),end=" ")
        i+=2
    print()
