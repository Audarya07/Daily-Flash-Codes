ft = int(input("Distance in feet:"))
print("Equivalent distance in cm is :",ft*30.48,"cm")
