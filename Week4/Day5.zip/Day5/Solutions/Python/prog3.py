for i in range(101):
    if i%7==0:
        continue
    else:
        print(i,end=" ")
print()
