for i in range(100):
    if i%2==0:
        continue
    else:
        print(i,end=" ")
