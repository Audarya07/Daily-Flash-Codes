dec = int(input("Enter decimal number:"))
ans = str(dec//8)+str(dec%8)
print("Octal number:",ans)
