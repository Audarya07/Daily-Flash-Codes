for i in range(10):
    if int(input()) < 0:
        print("Negative number entered,exiting the loop!!!")
        break

