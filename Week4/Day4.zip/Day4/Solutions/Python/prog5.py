for i in range(5):
    num1 = int(input())
    num2 = int(input())
    if num2<num1:
        print("Loop exited with input",num2)
        break

